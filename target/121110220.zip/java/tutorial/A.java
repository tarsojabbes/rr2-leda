package tutorial;

public interface A <E> extends B {

    public void m(E o);
}
