package tutorial;

public interface B {

    public void m(String o);
}
