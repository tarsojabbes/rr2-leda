package tutorial;

public class C implements A {

    public void m(Object o) {

    }

    public void m(String o) {

    }
}
