package vetor;

public interface VetorItem {
}
